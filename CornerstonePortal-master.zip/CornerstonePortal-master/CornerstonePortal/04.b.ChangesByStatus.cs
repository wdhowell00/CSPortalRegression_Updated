﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CornerstonePortal
{
    [TestClass]
    public class ChangesByStatus
    {
        [TestMethod]
        public void ChangesByStatusTest()
        {
        }
    }
}
